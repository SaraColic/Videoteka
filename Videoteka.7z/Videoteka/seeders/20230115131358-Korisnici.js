'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('Korisnicis', [
      {
        ime: 'admin',
        prezime: 'admin',
        username: 'admin',
        password: 'admin123',
        email: 'admin@gmail.com',
        tip: 0
      },
      {
        ime: 'zaposleni',
        prezime: 'zaposleni',
        username: 'xaposleni',
        password: 'zaposleni123',
        email: 'zaposleni@gmail.com',
        tip: 1
      },
      {
        ime: 'sara',
        prezime: 'colic',
        username: 'sara',
        password: 'sara123',
        email: 'sara@gmail.com',
        tip: 2
      },
      {
        ime: 'petar',
        prezime: 'prvulovic',
        username: 'petar',
        password: 'prtar123',
        email: 'petar@gmail.com',
        tip: 2
      },
      {
        ime: 'milos',
        prezime: 'milic',
        username: 'misa',
        password: 'misa123',
        email: 'misa@gmail.com',
        tip: 2
      },
    ], {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('Korisnicis', null, {});
  }
};
