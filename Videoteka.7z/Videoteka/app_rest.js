const express = require("express");
const { sequelize, Zanrovi, Direktor, Glumci, Serije, Sezone, Epizode, Filmovi, Korisnici, Komentari, Iznajmljeni } = require("./models");
require('dotenv').config();
const jwt = require('jsonwebtoken');
const cors = require('cors');

const app = express();

var corsOptions = {
    origin: 'http://127.0.0.1:8000',
    optionsSuccessStatus: 200
}


app.use(express.json());
app.use(cors(corsOptions));


const Joi = require('joi');

// Zanrovi


app.get('/zanrovi', (req, res) => {
    Zanrovi.findAll()
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

app.get('/zanrovi/:id', (req, res) => {
    Zanrovi.findOne({where: {id: req.params.id}})
    .then(row => {
        if(row == null){
            res.json({msg: `Zanr sa id-jem ${req.params.id} ne postoji`})
        }else{
            res.json(row)
        }
    })
    .catch(err => res.status(500).json(err))
})

const zanroviSema = Joi.object().keys({
    naziv: Joi.string().trim().min(0).max(255).required(),
    opis: Joi.string().trim().min(0).max(10000).required()
})

app.post('/zanrovi', (req, res) => {
    Joi.validate(req.body, zanroviSema, (err, result) => {
        if(err){
            res.status(400).send(err.details);
        }else{
            Zanrovi.create( {naziv: req.body.naziv, opis: req.body.opis} )
                .then( rows => res.json(rows) )
                .catch(err => res.status(500).json(err));
        }
    })
})


app.delete('/zanrovi/:id', (req, res) => {
    Zanrovi.destroy({where: {id: req.params.id}})
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

// Direktori

app.get('/direktori', (req, res) => {
    Direktor.findAll()
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

app.get('/direktori/:id', (req, res) => {
    Direktor.findOne({where: {id: req.params.id}})
    .then(row => {
        if(row == null){
            res.json({msg: `Direktor sa id-jem ${req.params.id} ne postoji`})
        }else{
            res.json(row)
        }
    })
    .catch(err => res.status(500).json(err))
})

const direktoriSema = Joi.object().keys({
    ime: Joi.string().trim().min(0).max(255).required(),
    prezime: Joi.string().trim().min(0).max(255).required()
})

app.post('/direktori', (req, res) => {
    Joi.validate(req.body, direktoriSema, (err, result) => {
        if(err){
            res.status(400).send(err.details);
        }else{
            Direktor.create( {ime: req.body.ime, prezime: req.body.prezime} )
                .then( rows => res.json(rows) )
                .catch(err => res.status(500).json(err));
        }
    })
})


app.delete('/direktori/:id', (req, res) => {
    Direktor.destroy({where: {id: req.params.id}})
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

// Glumci

app.get('/glumci', (req, res) => {
    Glumci.findAll()
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

app.get('/glumci/:id', (req, res) => {
    Glumci.findOne({where: {id: req.params.id}})
    .then(row => {
        if(row == null){
            res.json({msg: `Glumac sa id-jem ${req.params.id} ne postoji`})
        }else{
            res.json(row)
        }
    })
    .catch(err => res.status(500).json(err))
})

const glumciSema = Joi.object().keys({
    ime: Joi.string().trim().min(0).max(255).required(),
    prezime: Joi.string().trim().min(0).max(255).required()
})

app.post('/glumci', (req, res) => {
    Joi.validate(req.body, glumciSema, (err, result) => {
        if(err){
            res.status(400).send(err.details);
        }else{
            Glumci.create( {ime: req.body.ime, prezime: req.body.prezime} )
                .then( rows => res.json(rows) )
                .catch(err => res.status(500).json(err));
        }
    })
})

app.delete('/glumci/:id', (req, res) => {
    Glumci.destroy({where: {id: req.params.id}})
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

// Serije

app.get('/serije', (req, res) => {
    Serije.findAll()
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

app.get('/serije/:id', (req, res) => {
    Serije.findOne({where: {id: req.params.id}})
    .then(row => {
        if(row == null){
            res.json({msg: `Serija sa id-jem ${req.params.id} ne postoji`})
        }else{
            res.json(row)
        }
    })
    .catch(err => res.status(500).json(err))
})


app.delete('/serije/:id', (req, res) => {
    Serije.destroy({where: {id: req.params.id}})
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

// Sezone

app.get('/sezone', (req, res) => {
    Sezone.findAll()
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

app.get('/sezone/:id', (req, res) => {
    Sezone.findOne({where: {id: req.params.id}})
    .then(row => {
        if(row == null){
            res.json({msg: `Sezona sa id-jem ${req.params.id} ne postoji`})
        }else{
            res.json(row)
        }
    })
    .catch(err => res.status(500).json(err))
})


app.delete('/sezone/:id', (req, res) => {
    Sezone.destroy({where: {id: req.params.id}})
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

// Epizode

app.get('/epizode', (req, res) => {
    Epizode.findAll()
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

app.get('/epizode/:id', (req, res) => {
    Epizode.findOne({where: {id: req.params.id}})
    .then(row => {
        if(row == null){
            res.json({msg: `Epizoda sa id-jem ${req.params.id} ne postoji`})
        }else{
            res.json(row)
        }
    })
    .catch(err => res.status(500).json(err))
})


app.delete('/epizode/:id', (req, res) => {
    Epizode.destroy({where: {id: req.params.id}})
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

// Filmovi

app.get('/filmovi', (req, res) => {
    Filmovi.findAll()
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

app.get('/filmovi/:id', (req, res) => {
    Filmovi.findOne({where: {id: req.params.id}})
    .then(row => {
        if(row == null){
            res.json({msg: `Film sa id-jem ${req.params.id} ne postoji`})
        }else{
            res.json(row)
        }
    })
    .catch(err => res.status(500).json(err))
})


app.delete('/filmovi/:id', (req, res) => {
    Filmovi.destroy({where: {id: req.params.id}})
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

// Korisnici

app.get('/korisnici', (req, res) => {
    Korisnici.findAll()
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

app.get('/korisnici/:id', (req, res) => {
    Korisnici.findOne({where: {id: req.params.id}})
    .then(row => {
        if(row == null){
            res.json({msg: `Korisnik sa id-jem ${req.params.id} ne postoji`})
        }else{
            res.json(row)
        }
    })
    .catch(err => res.status(500).json(err))
})


app.delete('/korisnici/:id', (req, res) => {
    Korisnici.destroy({where: {id: req.params.id}})
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})
// Komentari

app.get('/komentari', (req, res) => {
    Komentari.findAll()
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

app.get('/komentari/:id', (req, res) => {
    Komentari.findOne({where: {id: req.params.id}})
    .then(row => {
        if(row == null){
            res.json({msg: `Komenatr sa id-jem ${req.params.id} ne postoji`})
        }else{
            res.json(row)
        }
    })
    .catch(err => res.status(500).json(err))
})


app.delete('/komentari/:id', (req, res) => {
    Komentari.destroy({where: {id: req.params.id}})
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

//Iznajmljeni

app.get('/iznajmljeni', (req, res) => {
    Iznajmljeni.findAll()
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})

app.get('/iznajmljeni/:id', (req, res) => {
    Iznajmljeni.findOne({where: {id: req.params.id}})
    .then(row => {
        if(row == null){
            res.json({msg: `Iznajmljeni sa id-jem ${req.params.id} ne postoji`})
        }else{
            res.json(row)
        }
    })
    .catch(err => res.status(500).json(err))
})



app.delete('/iznajmljeni/:id', (req, res) => {
    Iznajmljeni.destroy({where: {id: req.params.id}})
    .then(rows => res.json(rows))
    .catch(err => res.status(500).json(err))
})



app.listen({ port: 8001 }, async () => {
    await sequelize.authenticate();
});

